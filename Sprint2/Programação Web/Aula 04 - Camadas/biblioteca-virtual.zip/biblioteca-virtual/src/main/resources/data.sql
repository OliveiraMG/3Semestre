INSERT INTO livro
    (titulo, autor, data_publicacao, preco, disponibilidade_estoque)
VALUES
    ('O Senhor dos Anéis: A Sociedade do Anel', 'J. R. R. Tolkien', '1954-07-29', 39.9, true),
    ('O Hobbit', 'J. R. R. Tolkien', '1937-09-21', 49.9, true),
    ('O Silmarillion', 'J. R. R. Tolkien', '1977-09-15', 39.9, true),
    ('O Guia do Mochileiro das Galáxias', 'Douglas Adams', '1979-10-12', 59.9, true),
    ('O Restaurante no Fim do Universo', 'Douglas Adams', '1980-10-01', 29.9, true)
    ('A cabana', 'William P. Young', '2007-01-01', 89.9, false)
    ('O Código Da Vinci', 'Dan Brown', '2003-03-18', 49.9, true)
    ('Anjos e Demônios', 'Dan Brown', '2000-05-01', 59.9, true)
    ('O Símbolo Perdido', 'Dan Brown', '2009-09-15', 29.9, true)
    ('Inferno', 'Dan Brown', '2013-05-14', 209.9, false)
    ('Origem', 'Dan Brown', '2017-10-03', 59.9, true)