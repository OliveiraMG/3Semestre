package com.example.bibliotecavirtual;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliotecaVirtualApplicationTests {

	@Test
	void contextLoads() {
	}

}
