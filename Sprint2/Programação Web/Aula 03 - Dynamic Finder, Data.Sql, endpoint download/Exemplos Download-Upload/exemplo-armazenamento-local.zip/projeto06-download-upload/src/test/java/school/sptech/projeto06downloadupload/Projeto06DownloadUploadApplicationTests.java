package school.sptech.projeto06downloadupload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projeto06DownloadUploadApplicationTests {

	@Test
	void contextLoads() {
	}

}
