package school.sptech.projeto06downloadupload.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import school.sptech.projeto06downloadupload.dominio.Arquivo;

public interface ArquivoRepository extends JpaRepository<Arquivo, Integer> {
}
