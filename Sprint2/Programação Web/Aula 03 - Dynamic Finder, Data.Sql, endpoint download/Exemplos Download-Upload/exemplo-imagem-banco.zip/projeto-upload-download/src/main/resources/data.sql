insert into planta (nome) values
('Girassol'),
('Palmeira'),
('Samambaia');