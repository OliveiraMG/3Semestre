package sptech.projetouploaddownload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoUploadDownloadApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoUploadDownloadApplication.class, args);
	}

}
