import React, { useState } from 'react';
import axios from 'axios';

function App() {

  const [id, setId] = useState(0);
  const [picture, setPicture] = useState(null);
  const [imgData, setImgData] = useState(null);

  const onSubmitFile = e => {
    e.preventDefault();

    const reader = new FileReader();

    reader.addEventListener("load", () => {
      send(reader.result);
    });

    reader.readAsArrayBuffer(picture);
  }

  const send = (result) => {

    const headers = {
      "Accept": "application/json, image/*, */*",
      'Content-Type': picture.type
    };
    
    axios.patch(`http://localhost:8080/plantas/foto/${id}`,
      result, { headers }).then((response) => {
        console.log(response);
      }, (error) => {
        console.log(error);
      });
  }

  const changeId = e => setId(e.target.value);

  const onChangeFile = e => {
    if (e.target.files[0]) {

      const reader = new FileReader();

      setPicture(e.target.files[0]);

      reader.addEventListener("load", () => {
        setImgData(reader.result);
      });

      reader.readAsDataURL(e.target.files[0]);
    }
  }

  return (
    <div className="App">
      <div className="wrapper">
        <form className="form" onSubmit={onSubmitFile}>
          <h2 className="titulo">Exemplo upload de arquivos</h2>
          <div className="wrapper-arquivo-registrado">
            <input id="arquivo" type="file" onChange={onChangeFile} />
            <div className="preview">
              <img className="preview-arquivo" src={imgData} />
            </div>
            <p>digite o ID da planta:</p>
            <input id="idFoto" onChange={changeId} />
          </div>

          <button className="enviar">Enviar</button>
        </form>
      </div>
    </div>
  );
}

export default App;
