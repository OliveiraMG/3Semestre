package com.example.filmesIMyDB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FilmesIMyDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(FilmesIMyDbApplication.class, args);
	}

}
