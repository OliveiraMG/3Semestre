package com.example.filmesIMyDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilmesIMyDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
