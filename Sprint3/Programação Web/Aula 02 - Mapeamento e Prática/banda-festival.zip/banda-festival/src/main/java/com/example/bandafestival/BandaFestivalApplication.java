package com.example.bandafestival;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BandaFestivalApplication {

	public static void main(String[] args) {
		SpringApplication.run(BandaFestivalApplication.class, args);
	}

}
