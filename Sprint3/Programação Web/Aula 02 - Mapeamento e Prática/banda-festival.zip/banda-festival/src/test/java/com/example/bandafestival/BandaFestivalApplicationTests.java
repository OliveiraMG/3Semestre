package com.example.bandafestival;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BandaFestivalApplicationTests {

	@Test
	void contextLoads() {
	}

}
