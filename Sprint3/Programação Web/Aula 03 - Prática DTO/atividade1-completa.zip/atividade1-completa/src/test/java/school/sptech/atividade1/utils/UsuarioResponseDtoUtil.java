package school.sptech.atividade1.utils;

public class UsuarioResponseDtoUtil {

    public static final String USUARIO_RESPONSE_DTO_ID = "id";
    public static final String USUARIO_RESPONSE_DTO_NOME_COMPLETO = "nomeCompleto";
    public static final String USUARIO_RESPONSE_DTO_DOCUMENTO = "documento";
    public static final String USUARIO_RESPONSE_DTO_DATA_NASCIMENTO = "dataNascimento";
    public static final String USUARIO_RESPONSE_DTO_CONTATO = "contato";
    public static final String METODO_USUARIO_RESPONSE_DTO_IDADE = "getIdade";
}
