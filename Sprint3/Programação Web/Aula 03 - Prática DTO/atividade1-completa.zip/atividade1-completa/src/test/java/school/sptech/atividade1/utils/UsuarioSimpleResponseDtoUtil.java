package school.sptech.atividade1.utils;

public class UsuarioSimpleResponseDtoUtil {

    public static final String USUARIO_SIMPLE_RESPONSE_DTO_ID = "id";
    public static final String USUARIO_SIMPLE_RESPONSE_DTO_NOME_COMPLETO = "nomeCompleto";
}
