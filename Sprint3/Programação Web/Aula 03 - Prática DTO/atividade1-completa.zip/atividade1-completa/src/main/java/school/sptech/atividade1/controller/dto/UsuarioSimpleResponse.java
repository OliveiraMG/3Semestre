package school.sptech.atividade1.controller.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

//FIXME: Completar a classe
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UsuarioSimpleResponse {

    private int id;

    private String nomeCompleto;

}
