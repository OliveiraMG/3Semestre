package com.example.estoque.matheus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EstoqueMatheusGabriel01222100Application {

	public static void main(String[] args) {
		SpringApplication.run(EstoqueMatheusGabriel01222100Application.class, args);
	}

}
