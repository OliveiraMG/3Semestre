package com.example.estoque.matheus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstoqueMatheusGabriel01222100ApplicationTests {

	@Test
	void contextLoads() {
	}

}
