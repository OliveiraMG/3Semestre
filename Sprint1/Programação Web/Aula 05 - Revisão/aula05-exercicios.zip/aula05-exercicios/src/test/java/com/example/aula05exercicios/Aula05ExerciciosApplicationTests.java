package com.example.aula05exercicios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula05ExerciciosApplicationTests {

	@Test
	void contextLoads() {
	}

}
