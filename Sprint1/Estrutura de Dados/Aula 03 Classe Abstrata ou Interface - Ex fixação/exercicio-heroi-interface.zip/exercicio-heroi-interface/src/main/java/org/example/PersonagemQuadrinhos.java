package org.example;

public interface PersonagemQuadrinhos {
    public void treinar();
}
