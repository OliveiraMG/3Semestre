package org.example;

public interface BonusCalculavel {

    public abstract double getValorBonus();

}
